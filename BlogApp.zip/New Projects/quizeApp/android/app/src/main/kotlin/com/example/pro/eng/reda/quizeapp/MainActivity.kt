package com.example.pro.eng.reda.quizeapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
