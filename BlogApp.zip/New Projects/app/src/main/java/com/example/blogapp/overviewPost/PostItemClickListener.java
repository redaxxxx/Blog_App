package com.example.blogapp.overviewPost;
import com.example.blogapp.data.Post;
public interface PostItemClickListener {
    void onItemClickListener(Post post);
}
