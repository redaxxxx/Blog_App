package com.example.blogapp;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;

import com.example.blogapp.data.Post;
import com.example.blogapp.network.ServiceHelper;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Repository {

    private MutableLiveData<List<Post>> listMutableLiveData = new MutableLiveData<>();
    public MutableLiveData<List<Post>> getAllPost(){
        ServiceHelper.getInstance().getAllPosts().enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
                if (response.isSuccessful()){
                    if (response.body() != null){
                        listMutableLiveData.setValue(response.body());
                    }else {
                        listMutableLiveData.postValue(null);
                    }
                }else{
                    Log.d(Utils.TAG, "Response is Failed");
                }
            }

            @Override
            public void onFailure(Call<List<Post>> call, Throwable t) {
                Log.d(Utils.TAG, t.getLocalizedMessage());
            }
        });
        return listMutableLiveData;
    }


}
